package edu.godzilla.godzilla_ecom_site;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GodzillaEcomSiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(GodzillaEcomSiteApplication.class, args);
	}

}
