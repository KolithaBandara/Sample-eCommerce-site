package edu.godzilla.godzilla_ecom_site;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GodzillaEcomSiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
